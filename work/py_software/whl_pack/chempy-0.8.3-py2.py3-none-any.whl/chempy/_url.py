__url__ = "https://github.com/bjodah/chempy"
