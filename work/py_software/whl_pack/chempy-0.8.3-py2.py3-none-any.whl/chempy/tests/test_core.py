# -*- coding: utf-8 -*-


def test_imports():
    from .. import MassAction  # noqa
