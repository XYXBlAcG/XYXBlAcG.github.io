# -*- coding: utf-8 -*-
"""
This package implements various parameterisations of properties from the
literature with relevance in chemistry.
"""
