# -*- coding: utf-8 -*-
"""
This package collects utility functions used throughout the ``ChemPy`` package.
"""

from .pyutil import NoConvergence
